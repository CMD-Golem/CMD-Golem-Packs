schedule function keylock:sec 20t

execute as @e[tag=keylock_container] at @s run function keylock:container/unlock/prepare
execute as @e[tag=keylock_door] run kill @s
execute as @e[tag=keylock_trapgate] run kill @s