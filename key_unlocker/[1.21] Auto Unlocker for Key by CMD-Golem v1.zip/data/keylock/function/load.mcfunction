scoreboard objectives remove keylock
scoreboard objectives remove keylock_craft
scoreboard objectives remove keylock_count
scoreboard objectives remove keylock_settings
scoreboard objectives remove keylock_use

function keylock:sec