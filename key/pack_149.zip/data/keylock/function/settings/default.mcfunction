scoreboard players set #default keylock 1

scoreboard players set #damage keylock 1
scoreboard players set #enable_containers keylock 1
