execute if block ~ ~ ~ #keylock:trapgate run function keylock:trapgate/auto_door/prepare
execute unless score #execute_code keylock matches 20.. positioned ^ ^ ^1 if block ~ ~ ~ #keylock:trapgate run function keylock:trapgate/auto_door/prepare
execute unless score #execute_code keylock matches 20.. positioned ^ ^ ^2 if block ~ ~ ~ #keylock:trapgate run function keylock:trapgate/auto_door/prepare