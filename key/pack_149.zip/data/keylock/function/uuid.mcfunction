scoreboard players add #uuidstore keylock 1
scoreboard players operation @s keylock = #uuidstore keylock
scoreboard players set @s keylock_count 0