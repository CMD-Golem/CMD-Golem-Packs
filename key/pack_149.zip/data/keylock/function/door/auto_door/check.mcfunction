execute if block ~ ~ ~ #keylock:doors run function keylock:door/auto_door/prepare
execute unless score #execute_code keylock matches 20.. positioned ^ ^ ^1 if block ~ ~ ~ #keylock:doors run function keylock:door/auto_door/prepare
execute unless score #execute_code keylock matches 20.. positioned ^ ^ ^2 if block ~ ~ ~ #keylock:doors run function keylock:door/auto_door/prepare