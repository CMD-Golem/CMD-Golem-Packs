$data remove storage keylock:item_safe storage[{x:$(x)d,y:$(y)d,z:$(z)d}]
kill @s